from __future__ import annotations

from fastapi.testclient import TestClient

from plaud_worker import api
from plaud_worker.config import Settings
from plaud_worker.phone_context import extract_phone_context
from plaud_worker.store import JobStore


class FakeSummarizer:
    model = "test-model"

    def __init__(self, result):
        self.result = result
        self.prompt = ""

    def _generate_json(self, prompt, **_):
        self.prompt = prompt
        return self.result


class IdleRunner:
    running = True

    def start(self):
        pass

    def stop(self):
        pass


def candidate(**overrides):
    return {
        "subject_type": "person",
        "relation": "called_target",
        "label": "John",
        "description": "eigenaar van een kringloopwinkel",
        "confidence": 88,
        "evidence": "Hij heet John, eigenaar van de kringloopwinkel.",
        **overrides,
    }


def test_phone_context_keeps_only_literal_label_and_evidence():
    text = "Bel [DOELNUMMER]. Hij heet John, eigenaar van de kringloopwinkel."
    result = extract_phone_context(FakeSummarizer(candidate()), text, [])

    assert result["label"] == "John"
    assert result["confidence"] == 88
    assert result["model"] == "test-model"


def test_phone_context_rejects_hallucinated_identity():
    text = "Bel [DOELNUMMER]. Het is een klasgenoot."
    result = extract_phone_context(
        FakeSummarizer(candidate(label="John", evidence="Het is een klasgenoot.")),
        text,
        [],
    )

    assert result["subject_type"] == "unknown"
    assert result["label"] == ""
    assert result["confidence"] == 0


def test_phone_context_endpoint_requires_auth_and_bounds_input(tmp_path):
    settings = Settings(api_token="secret", data_dir=tmp_path)
    summarizer = FakeSummarizer(candidate())
    with TestClient(
        api.create_app(
            settings=settings,
            store=JobStore(tmp_path / "jobs.sqlite3"),
            runner=IdleRunner(),
            summarizer=summarizer,  # type: ignore[arg-type]
        )
    ) as client:
        unauthorized = client.post("/v1/phone-context", json={"text": "Bel [DOELNUMMER]."})
        response = client.post(
            "/v1/phone-context",
            json={
                "text": "Bel [DOELNUMMER]. Hij heet John, eigenaar van de kringloopwinkel.",
                "nearby_entities": [{"name": "John", "type": "person"}],
            },
            headers={"Authorization": "Bearer secret"},
        )
        oversized = client.post(
            "/v1/phone-context",
            json={"text": "x" * 10_001},
            headers={"Authorization": "Bearer secret"},
        )

    assert unauthorized.status_code == 401
    assert response.status_code == 200
    assert response.json()["label"] == "John"
    assert oversized.status_code == 422
    assert "John (person)" in summarizer.prompt
