from __future__ import annotations

import importlib.util
import logging
import math
import secrets
import struct
import time
import uuid
import wave
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import AsyncIterator
from urllib.parse import unquote

import httpx
from fastapi import (
    Depends,
    FastAPI,
    File,
    Form,
    Header,
    HTTPException,
    Request,
    UploadFile,
    status,
)
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse

from .config import Settings
from .entities import EntityRequest, extract_entities
from .phone_context import PhoneContextRequest, extract_phone_context
from .downloader import AudioDownloader
from .models import (
    HealthView,
    JobSubmission,
    JobView,
    SpeakerDetachView,
    SpeakerMergeRequest,
    SpeakerMergeView,
    SpeakerProfileView,
    SpeakerRecordingDetach,
    SpeakerRename,
    SpeakerSummaryRequest,
    SpeakerSummaryView,
)
from .runner import JobRunner
from .speaker_store import SpeakerStore
from .store import JobStore
from .summarizer import OllamaSummarizer
from .transcriber import FasterWhisperTranscriber


logger = logging.getLogger(__name__)


def dependency_health(ollama_url: str) -> tuple[bool, bool, str | None]:
    faster_whisper_available = importlib.util.find_spec("faster_whisper") is not None
    try:
        response = httpx.get(f"{ollama_url.rstrip('/')}/api/version", timeout=2.0)
        response.raise_for_status()
        version = str(response.json().get("version", "")).strip() or None
        return faster_whisper_available, True, version
    except (httpx.HTTPError, ValueError, TypeError):
        return faster_whisper_available, False, None


def cuda_device_count() -> int | None:
    try:
        from ctranslate2 import get_cuda_device_count

        return int(get_cuda_device_count())
    except Exception:
        logger.exception("Could not query CTranslate2 CUDA devices")
        return None


def cleanup_stale_storyteller_uploads(upload_dir: Path) -> tuple[int, int]:
    removed = 0
    removed_bytes = 0
    for upload_path in upload_dir.glob("storyteller-*"):
        if not upload_path.is_file():
            continue
        try:
            removed_bytes += upload_path.stat().st_size
            upload_path.unlink()
            removed += 1
        except OSError:
            logger.exception("Could not remove stale Storyteller upload: %s", upload_path.name)
    if removed:
        logger.info(
            "Removed %d stale Storyteller upload(s), reclaiming %.1f MiB",
            removed,
            removed_bytes / (1024 * 1024),
        )
    return removed, removed_bytes


def write_cuda_probe(path: Path) -> None:
    sample_rate = 16_000
    sample_count = sample_rate
    samples = (
        int(1_000 * math.sin(2 * math.pi * 440 * index / sample_rate))
        for index in range(sample_count)
    )
    frames = struct.pack(f"<{sample_count}h", *samples)
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(sample_rate)
        output.writeframes(frames)


def create_app(
    settings: Settings | None = None,
    store: JobStore | None = None,
    runner: JobRunner | None = None,
    speaker_store: SpeakerStore | None = None,
    summarizer: OllamaSummarizer | None = None,
) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    upload_dir = settings.data_dir / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    cleanup_stale_storyteller_uploads(upload_dir)
    store = store or JobStore(settings.data_dir / "jobs.sqlite3")
    speaker_store = speaker_store or SpeakerStore(
        settings.data_dir,
        match_threshold=settings.speaker_match_threshold,
        sample_seconds=settings.speaker_sample_seconds,
    )
    summarizer = summarizer or OllamaSummarizer(
        settings.ollama_url,
        settings.ollama_model,
        settings.summary_words,
    )
    runner = runner or JobRunner(
        store=store,
        downloader=AudioDownloader(
            settings.data_dir / "audio", settings.max_audio_bytes, upload_dir=upload_dir
        ),
        transcriber=FasterWhisperTranscriber(settings, speaker_store=speaker_store),
        summarizer=summarizer,
        summary_required=settings.summary_required,
    )

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        runner.start()
        try:
            yield
        finally:
            runner.stop()

    app = FastAPI(title="Plaud Whisper Worker", version="0.2.0", lifespan=lifespan)

    def authorize(authorization: str | None = Header(default=None)) -> None:
        expected = settings.api_token
        supplied = authorization.removeprefix("Bearer ").strip() if authorization else ""
        if not expected or not supplied or not secrets.compare_digest(expected, supplied):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid worker token")

    @app.get("/health", response_model=HealthView)
    def health() -> HealthView:
        faster_whisper_available, ollama_available, ollama_version = dependency_health(settings.ollama_url)
        transcriber = getattr(runner, "transcriber", None)
        try:
            diarization_available = importlib.util.find_spec("pyannote.audio") is not None
        except ModuleNotFoundError:
            diarization_available = False
        progress = getattr(transcriber, "inference_progress", None) or {}
        return HealthView(
            status="ok",
            model=settings.model,
            device=settings.device,
            compute_type=settings.compute_type,
            ollama_model=settings.ollama_model,
            worker_running=runner.running,
            faster_whisper_available=faster_whisper_available,
            ollama_available=ollama_available,
            ollama_version=ollama_version,
            diarization_available=diarization_available,
            diarization_configured=settings.diarization_enabled and bool(settings.huggingface_token),
            diarization_model=settings.diarization_model if settings.diarization_enabled else None,
            cuda_device_count=cuda_device_count(),
            model_loaded=bool(getattr(transcriber, "model_loaded", False)),
            last_inference_at=getattr(transcriber, "last_inference_at", None),
            last_inference_error=getattr(transcriber, "last_inference_error", None),
            inference_recording_id=progress.get("recording_id"),
            inference_phase=progress.get("phase"),
            inference_duration=progress.get("duration"),
            inference_processed_seconds=progress.get("processed_seconds"),
            inference_percent=progress.get("percent"),
        )

    @app.get("/v1/status", response_model=HealthView)
    def protected_status(_: None = Depends(authorize)) -> HealthView:
        return health()

    def storyteller_config_response() -> dict[str, int | str]:
        # This worker emits one global timeline. Advertising exactly one
        # processor lets Storyteller skip its heuristic split detection.
        return {
            "threads": 1,
            "processors": 1,
            "model": settings.model,
            "maxThreads": 1,
            "maxProcessors": 1,
        }

    @app.get("/config")
    def storyteller_config(_: None = Depends(authorize)) -> dict[str, int | str]:
        return storyteller_config_response()

    @app.post("/config")
    def update_storyteller_config(
        processors: int = Form(default=1),
        threads: int = Form(default=1),
        _: None = Depends(authorize),
    ) -> dict[str, int | str]:
        if processors != 1 or threads != 1:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="This worker uses exactly one global timeline processor.",
            )
        return storyteller_config_response()

    @app.get("/health/deep")
    async def deep_health(_: None = Depends(authorize)) -> dict[str, object]:
        transcriber = getattr(runner, "transcriber", None)
        if transcriber is None:
            raise HTTPException(status_code=503, detail="Transcriber is unavailable")

        probe_path = upload_dir / f"health-probe-{uuid.uuid4().hex}.wav"
        write_cuda_probe(probe_path)
        started = time.perf_counter()
        try:
            result = await run_in_threadpool(
                lambda: transcriber.transcribe(
                    probe_path,
                    "en",
                    "health-probe",
                    diarize=False,
                    word_timestamps=True,
                    temperature=0.0,
                    use_default_language=False,
                    vad_filter=False,
                )
            )
            return {
                "status": "ok",
                "model": settings.model,
                "device": settings.device,
                "compute_type": settings.compute_type,
                "cuda_device_count": cuda_device_count(),
                "model_loaded": bool(getattr(transcriber, "model_loaded", False)),
                "elapsed_ms": round((time.perf_counter() - started) * 1000),
                "segments": len(result.segments),
            }
        finally:
            probe_path.unlink(missing_ok=True)

    @app.post("/v1/jobs", response_model=JobView, status_code=status.HTTP_202_ACCEPTED)
    def submit_job(submission: JobSubmission, _: None = Depends(authorize)) -> JobView:
        job = store.submit(submission)
        runner.notify()
        return job

    @app.post("/v1/uploads", response_model=JobView, status_code=status.HTTP_202_ACCEPTED)
    async def upload_audio(
        request: Request,
        x_upload_filename: str | None = Header(default=None),
        x_recorded_at: str | None = Header(default=None),
        x_language: str | None = Header(default=None),
        _: None = Depends(authorize),
    ) -> JobView:
        try:
            filename = unquote(x_upload_filename or "", errors="strict")
        except UnicodeDecodeError as error:
            raise HTTPException(status_code=400, detail="Invalid upload filename") from error
        if (
            not filename
            or len(filename) > 500
            or Path(filename).name != filename
            or Path(filename).suffix.lower()
            not in {".aac", ".flac", ".m4a", ".mp3", ".mp4", ".mpeg", ".ogg", ".opus", ".wav", ".webm"}
        ):
            raise HTTPException(status_code=400, detail="Unsupported audio filename")

        declared_size = request.headers.get("content-length", "").strip()
        if declared_size:
            try:
                if int(declared_size) > settings.max_audio_bytes:
                    raise HTTPException(status_code=413, detail="Audio file is too large")
            except ValueError as error:
                raise HTTPException(status_code=400, detail="Invalid content length") from error

        recorded_at = datetime.now(UTC)
        if x_recorded_at:
            try:
                recorded_at = datetime.fromisoformat(x_recorded_at.replace("Z", "+00:00"))
            except ValueError as error:
                raise HTTPException(status_code=400, detail="Invalid recording date") from error

        upload_id = uuid.uuid4().hex
        partial_path = upload_dir / f"{upload_id}.media.part"
        final_path = upload_dir / f"{upload_id}.media"
        written = 0
        try:
            with partial_path.open("xb") as output:
                async for chunk in request.stream():
                    written += len(chunk)
                    if written > settings.max_audio_bytes:
                        raise HTTPException(status_code=413, detail="Audio file is too large")
                    output.write(chunk)
            if written == 0:
                raise HTTPException(status_code=400, detail="Audio file is empty")
            partial_path.replace(final_path)
            job = store.submit(
                JobSubmission(
                    plaud_file_id=f"upload:{upload_id}",
                    audio_url=f"local-upload:{upload_id}",
                    title=Path(filename).stem.strip() or "Handmatige opname",
                    recorded_at=recorded_at,
                    duration_ms=0,
                    language=x_language,
                )
            )
        except Exception:
            partial_path.unlink(missing_ok=True)
            final_path.unlink(missing_ok=True)
            raise
        runner.notify()
        return job

    @app.post("/v1/entities")
    def detect_entities(payload: EntityRequest, _: None = Depends(authorize)) -> dict:
        return extract_entities(summarizer, payload.text)

    @app.post("/v1/phone-context")
    def classify_phone_context(payload: PhoneContextRequest, _: None = Depends(authorize)) -> dict:
        return extract_phone_context(
            summarizer,
            payload.text,
            [entity.model_dump() for entity in payload.nearby_entities],
        )

    @app.post("/v1/media/transcriptions")
    @app.post("/audio/transcriptions")
    async def storyteller_transcription(
        file: UploadFile = File(...),
        language: str | None = Form(default=None),
        recording_id: str | None = Form(default=None, max_length=200),
        temperature: float = Form(default=0.0, ge=0.0, le=1.0),
        response_format: str | None = Form(default=None),
        diarize: bool = Form(default=False),
        _: None = Depends(authorize),
    ) -> dict[str, object]:
        """Transcribe an upload using the endpoint expected by Storyteller.

        Storyteller's remote-whisper engine sends WAV uploads to this OpenAI/
        whisper.cpp-compatible endpoint and expects a ``verbose_json`` response.
        This direct path deliberately bypasses the Plaud queue and summarizer so
        that its request does not occupy a completed Plaud job or retain audio.
        """
        if response_format not in {None, "", "verbose_json"}:
            raise HTTPException(
                status_code=400,
                detail="Only response_format=verbose_json is supported.",
            )

        supplied_name = Path(file.filename or "audio.wav").name
        suffix = Path(supplied_name).suffix.lower()
        if suffix not in {".aac", ".flac", ".m4a", ".mp3", ".mp4", ".mpeg", ".ogg", ".opus", ".wav", ".webm"}:
            suffix = ".wav"

        upload_path = upload_dir / f"storyteller-{uuid.uuid4().hex}{suffix}"
        written = 0
        started = time.perf_counter()
        try:
            with upload_path.open("xb") as output:
                while chunk := await file.read(1024 * 1024):
                    written += len(chunk)
                    if written > settings.max_audio_bytes:
                        raise HTTPException(status_code=413, detail="Audio file is too large")
                    output.write(chunk)
            if written == 0:
                raise HTTPException(status_code=400, detail="Audio file is empty")

            logger.info(
                "Starting Storyteller transcription (%d bytes, language=%s, temperature=%s)",
                written,
                language or "auto",
                temperature,
            )

            def transcribe_for_storyteller():
                return runner.transcriber.transcribe(
                    upload_path,
                    language or None,
                    recording_id or f"storyteller:{uuid.uuid4().hex}",
                    diarize=diarize,
                    word_timestamps=True,
                    temperature=temperature,
                    use_default_language=False,
                    # Audioscraper requests diarization explicitly. Enroll
                    # those voices so a manually assigned name is reused in
                    # later podcasts and videos. Storyteller leaves diarize
                    # false and therefore never creates a profile here.
                    enroll_speakers=diarize,
                )

            result = await run_in_threadpool(transcribe_for_storyteller)
            logger.info(
                "Completed Storyteller transcription in %.1fs (%d segments, language=%s)",
                time.perf_counter() - started,
                len(result.segments),
                result.language,
            )
            return {
                "text": result.text,
                "language": result.language,
                "duration": result.duration,
                "segments": [
                    {
                        "id": index,
                        "start": segment.start,
                        "end": segment.end,
                        "text": segment.text,
                        **({"speaker": segment.speaker} if segment.speaker else {}),
                        **({"speaker_id": segment.speaker_id} if segment.speaker_id else {}),
                        **(
                            {
                                "words": [
                                    {
                                        "word": word.word,
                                        "start": word.start,
                                        "end": word.end,
                                        **(
                                            {"probability": word.probability}
                                            if word.probability is not None
                                            else {}
                                        ),
                                    }
                                    for word in segment.words
                                ]
                            }
                            if segment.words
                            else {}
                        ),
                    }
                    for index, segment in enumerate(result.segments)
                ],
                "diarization_model": result.diarization_model,
                "diarization_error": result.diarization_error,
            }
        finally:
            await file.close()
            upload_path.unlink(missing_ok=True)

    @app.get("/v1/jobs/{job_id}", response_model=JobView)
    def get_job(job_id: str, _: None = Depends(authorize)) -> JobView:
        job = store.get(job_id)
        if job is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
        return job

    @app.get("/v1/speakers", response_model=list[SpeakerProfileView])
    def list_speakers(_: None = Depends(authorize)) -> list[SpeakerProfileView]:
        return speaker_store.list_profiles()

    @app.patch("/v1/speakers/{profile_id}", response_model=SpeakerProfileView)
    def rename_speaker(
        profile_id: str,
        update: SpeakerRename,
        _: None = Depends(authorize),
    ) -> SpeakerProfileView:
        profile = speaker_store.rename(profile_id, update.name)
        if profile is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Speaker not found")
        return profile

    @app.post("/v1/speakers/{profile_id}/merge", response_model=SpeakerMergeView)
    def merge_speakers(
        profile_id: str,
        update: SpeakerMergeRequest,
        _: None = Depends(authorize),
    ) -> SpeakerMergeView:
        try:
            result = speaker_store.merge_profiles(profile_id, update.source_profile_ids)
        except ValueError as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error
        if result is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Speaker not found")
        profile, merged_profile_ids = result
        return SpeakerMergeView(profile=profile, merged_profile_ids=merged_profile_ids)

    @app.post("/v1/speaker-summary", response_model=SpeakerSummaryView)
    async def summarize_speaker(
        update: SpeakerSummaryRequest,
        _: None = Depends(authorize),
    ) -> SpeakerSummaryView:
        result = await run_in_threadpool(summarizer.summarize_speaker, update.utterances)
        return SpeakerSummaryView(**result)

    @app.get("/v1/speakers/{profile_id}/sample")
    def speaker_sample(profile_id: str, _: None = Depends(authorize)) -> FileResponse:
        sample = speaker_store.sample_path(profile_id)
        if sample is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sample not found")
        return FileResponse(
            sample,
            media_type="audio/wav",
            headers={"Cache-Control": "private, max-age=300", "X-Content-Type-Options": "nosniff"},
        )

    @app.get("/v1/speakers/{profile_id}/recording-sample")
    def speaker_recording_sample(
        profile_id: str,
        recording_id: str,
        _: None = Depends(authorize),
    ) -> FileResponse:
        sample = speaker_store.recording_sample_path(profile_id, recording_id)
        if sample is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sample not found")
        return FileResponse(
            sample,
            media_type="audio/wav",
            headers={"Cache-Control": "private, max-age=300", "X-Content-Type-Options": "nosniff"},
        )

    @app.delete("/v1/speakers/{profile_id}/recordings", response_model=SpeakerDetachView)
    def detach_speaker_recording(
        profile_id: str,
        update: SpeakerRecordingDetach,
        _: None = Depends(authorize),
    ) -> SpeakerDetachView:
        try:
            result = speaker_store.detach_recording(profile_id, update.recording_id)
        except ValueError as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error
        if result is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Recording not found")
        profile, replacement = result
        return SpeakerDetachView(profile=profile, replacement=replacement)

    @app.post("/v1/speakers/{profile_id}/recordings", response_model=SpeakerProfileView)
    def backfill_speaker_recording(
        profile_id: str,
        update: SpeakerRecordingDetach,
        _: None = Depends(authorize),
    ) -> SpeakerProfileView:
        try:
            profile = speaker_store.backfill_recording(profile_id, update.recording_id)
        except ValueError as error:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error
        if profile is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Speaker not found")
        return profile

    return app
