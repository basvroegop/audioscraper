# Plaud Whisper Worker

Windows worker that downloads a temporary Plaud audio URL, transcribes it on an NVIDIA GPU with Faster Whisper, and creates a Dutch summary of at most 50 words with local Ollama.

For the target RTX 4080 Super the defaults are Faster Whisper `large-v3`, CUDA FP16, batch size 8, and Ollama `qwen3.5:9b`. The Ollama request uses structured JSON output, disables thinking, and unloads the model after summarizing.

## Configuration

The Windows installer creates `C:\PlaudWhisperWorker\worker.env.ps1`. Important settings:

- `PLAUD_WORKER_TOKEN`: bearer token shared only with the Obsidian plugin.
- `PLAUD_WHISPER_MODEL`: defaults to `large-v3`.
- `PLAUD_OLLAMA_MODEL`: defaults to `qwen3.5:9b`.
- `PLAUD_SUMMARY_WORDS`: defaults to `50`.

The worker stores its SQLite queue, streamed dashboard uploads, temporary audio,
and rotating logs under `%LOCALAPPDATA%\PlaudWhisperWorker`. Audio is deleted
after processing. Signed URLs and local upload references are removed from
completed jobs. Logs are written to `logs\worker.log` and rotate at 10 MiB with
five backups.

## Speaker labels

Speaker diarization uses the local `pyannote/speaker-diarization-community-1` model on the GPU. Accept the model conditions at `https://huggingface.co/pyannote/speaker-diarization-community-1`, create a read token, and then run `scripts\configure-diarization-windows.ps1`. The token is stored only in `worker.env.ps1`; the script downloads the gated model once and restarts the worker. Transcript segments are written with labels such as `SPEAKER_00` and `SPEAKER_01`. If no token is configured or diarization fails, transcription and summarization continue without speaker labels.

## Windows installation

Run from an administrator PowerShell in the copied `worker` directory:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install-windows.ps1
powershell -ExecutionPolicy Bypass -File C:\PlaudWhisperWorker\scripts\register-startup-task-windows.ps1
```

The installer uses official NVIDIA Python packages for CUDA 12 cuBLAS and cuDNN 9. The generated worker token remains in `worker.env.ps1`; copy its value into the Obsidian plugin settings without sharing it elsewhere.

## Development

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install ".[test]"
.\.venv\Scripts\python.exe -m pytest
```

The API listens on port `8765`. Only `/health` is public; job endpoints require `Authorization: Bearer <token>`.
`GET /health/deep` is protected and performs a real, short CUDA inference so it
can detect a broken model or CUDA runtime rather than only checking imports.

## Storyteller readalouds

The worker also exposes `POST /audio/transcriptions`, compatible with
Storyteller's **whisper.cpp (remote)** engine. It accepts the WAV upload that
Storyteller creates and returns a `verbose_json` transcript with word-level
timestamps. Storyteller's requested temperature is honored; when it omits a
language, Faster Whisper performs language detection. `GET /config` advertises
one processor because this worker returns a single global timeline, avoiding
Storyteller's heuristic split detection. Stale direct uploads left by an abrupt
process termination are removed at the next worker start.
The request uses the same worker token as Plaud, processes the audio directly
(without a Plaud job or summary), and deletes the temporary upload afterwards.

Faster Whisper, Pyannote, and Ollama GPU work is serialized to prevent competing
jobs from exhausting VRAM. The Scheduled Task starts both at boot and logon,
retries failures, and has `WakeToRun` enabled. An incoming HTTP request cannot by
itself wake a sleeping Windows PC; that still requires Wake-on-LAN from an
always-on device.

In Storyteller's transcription settings, choose **whisper.cpp (remote)** and
configure:

- Server URL: `http://192.168.1.28:8765`
- API key: the existing Plaud worker token

## Audioscraper

The LAN Audioscraper dashboard also uses this worker:

- `POST /v1/media/transcriptions`: alias of the existing direct audio-upload
  endpoint, with automatic language detection, timestamps and no speaker profiles.
- `POST /v1/entities`: authenticated JSON `{ "text": "..." }`, at most 20,000
  characters per request. Returns literal named entities and their categories
  using the configured local Ollama model. Hallucinated names are discarded.
- `POST /v1/phone-context`: authenticated JSON with a masked transcript window
  and nearby named entities. It classifies what a mentioned telephone number
  represents and returns a confidence score plus verbatim evidence. Proposed
  names and evidence are accepted only when they occur literally in the input.

Entity inference uses the same GPU lock as Plaud and Storyteller and unloads
Ollama after each request. Audioscraper stores its own queue, audio, transcripts
and entity occurrences; it does not add public speakers to Plaud voice profiles.
